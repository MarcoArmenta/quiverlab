"""Scalar algebra invariants: Loewy length, center, complexity (spec section 3.5).

Loewy length and center are exact over ANY Domain (radical-ideal powers / commutant
linear algebra). Complexity routes through the fast GF(p) engine (the minimal A^e
resolution's term growth), so it is prime-field-only and fails loudly otherwise, exactly
like the other engine-backed invariants."""
from quiverlab.fields import linalg


def _radical_basis_indices(A):
    """Indices of the basis labels lying in rad A = the arrow ideal (all non-idempotent
    basis paths, i.e. every label that is not 'e_v')."""
    return [i for i, lab in enumerate(A.basis_labels) if not lab.startswith("e_")]


def _ideal_product_span(A, gens_vectors, rad_idx):
    """Span (as a list of coordinate vectors) of gens * rad A = { g * r : g in gens,
    r a radical basis element }, reduced to an independent set via rref."""
    dom = A.domain
    rows = []
    for g in gens_vectors:
        for ri in rad_idx:
            prod = A.multiply(g, A._basis_vec(ri))
            rows.append(prod)
    if not rows:
        return []
    R, piv = linalg.rref(rows, dom)
    return [R[i] for i in range(len(piv))]


def loewy_length(A):
    """Least n with rad^n A = 0. rad^1 = arrow ideal; rad^{k+1} = rad^k * rad."""
    dom = A.domain
    rad_idx = _radical_basis_indices(A)
    if not rad_idx:
        return 1                                    # semisimple: rad = 0, rad^1 = 0
    current = [A._basis_vec(i) for i in rad_idx]     # rad^1 spanning set
    n = 1
    while current:
        nxt = _ideal_product_span(A, current, rad_idx)
        if not nxt:
            return n + 1                             # rad^{n+1} = 0
        current = nxt
        n += 1
        if n > A.dim + 1:                            # safety: nilpotent within dim steps
            return n
    return n


def center(A):
    """(dim Z(A), basis). Z(A) = { z : z*b = b*z for every basis element b }. Solve the
    stacked commutator system over the Domain; nullspace = the center."""
    dom = A.domain
    m = A.dim
    rows = []
    # unknown z = (z_0..z_{m-1}); for each basis b, (z*b - b*z) = 0 gives m linear rows.
    # coefficient of z_k in coordinate-c of (z*b - b*z): mult(e_k,b)[c] - mult(b,e_k)[c].
    for b in range(m):
        eb = A._basis_vec(b)
        for c in range(m):
            row = []
            for k in range(m):
                ek = A._basis_vec(k)
                left = A.multiply(ek, eb)[c]         # (z*b) coord c, coefficient of z_k
                right = A.multiply(eb, ek)[c]        # (b*z) coord c
                row.append(dom.sub(left, right))
            rows.append(row)
    basis = linalg.nullspace(rows, dom)
    return len(basis), basis


def complexity(A, n):
    """Apparent complexity of A from the minimal A^e (bimodule) resolution's term-
    dimension growth up to degree n. GF(p): the fast engine. Any other exact
    Domain: the E-relative (Cibils) Betti complex on a path-type basis (Plan 19)
    — same generator counts, gated by GF(p) parity tests. Returns complexity_of's
    honest label (int / None / '>=2').

    Plan 13: multi-vertex algebras are now exact — the engine builds the corner-typed
    minimal PROJECTIVE resolution (terms ``A^e·(e_v ⊗ e_w)``), so e.g. the
    ``linear_path_algebra(2) -> 0`` pin holds because the resolution genuinely
    terminates (2, 1, 0), not by the pre-Plan-13 silent zero-resolution bug.

    HONESTY GUARD — TRUNCATION REFUSED. A memory-truncated resolution build would
    contribute a silent prefix to the growth sequence, under-reporting the complexity
    (an early stop reads as if the resolution had genuinely terminated). The build's
    truncation marker (``truncated_at`` / the fourth return value below) is now
    consulted: if the minimal A^e resolution was truncated (memory or term-dimension
    cap) short of the full degree-``n`` growth sequence, this raises ``QuiverlabError``
    rather than certify a wrong number. Not reached in normal use -- the default caps
    are generous -- so the non-truncated return value is byte-identical to before.
    """
    from quiverlab.engine.scan3 import complexity_of
    from quiverlab.fields.primefield import PrimeField
    if not isinstance(A.domain, PrimeField):
        from quiverlab.invariants.betti import relative_betti_numbers
        # engine minimal_resolution(N) yields rks for degrees 0..N+1; feed
        # complexity_of the same-length growth sequence on the generic path
        return complexity_of(relative_betti_numbers(A, n + 1))
    from quiverlab.engine.adapter import to_engine
    from quiverlab.engine.resolutions_minimal import minimal_resolution
    from quiverlab.errors import QuiverlabError
    eng = to_engine(A)
    p = A.domain.p
    rks, cols, _e, _trunc = minimal_resolution(eng, n, p)
    if _trunc is not None:
        raise QuiverlabError(
            f"the minimal A^e resolution was truncated at degree {_trunc}: a "
            f"memory/term-dimension budget stopped the build short of the full "
            f"degree-{n} growth sequence, so the complexity growth sequence is "
            f"incomplete and complexity cannot be certified",
            hint="lower the target degree n below the truncation point, or raise the "
                 "resolution budget (max_term_dim / max_transient_bytes)")
    # rks[k] = number of A^e generators of P_k; term k-dimension is m^2 * rks[k].
    # MINIMAL FIX vs brief: minimal_resolution returns `rks` as a dict keyed by degree,
    # so `for r in rks` iterates the KEYS (0,1,2,..) not the ranks. Iterate the rank
    # VALUES in degree order so complexity_of reads the term-dimension growth sequence.
    seq = [max(0, rks[k]) for k in sorted(rks)]
    return complexity_of(seq)
